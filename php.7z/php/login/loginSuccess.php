<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Top Secret Club!</title>
</head>
<body>
<?php
  echo '<h2> Welcome to the Top Secret Club! </h2>';
  echo '<p> You are now part of a privileged clique </p>';
?>
</body>
</html>
